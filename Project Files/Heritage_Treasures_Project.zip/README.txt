Project Name: Heritage Treasures

Description:
This project analyzes global heritage sites data using MySQL for data management and Tableau for data visualization.

Tools Used:
- MySQL Workbench
- Tableau Desktop

Files Included:
1. Heritage_Treasures.twbx - Tableau Dashboard (Add your exported file here)
2. heritage_database.sql - Database File
3. Project_Report.pdf - Detailed Documentation

How to Run:
1. Import the .sql file into MySQL Workbench.
2. Open the .twbx file in Tableau.
3. Refresh data connection if required.

Created By:
Arjun Devarakonda
