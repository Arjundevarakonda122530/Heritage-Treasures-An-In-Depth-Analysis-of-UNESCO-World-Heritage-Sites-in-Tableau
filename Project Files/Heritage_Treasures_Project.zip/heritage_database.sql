
-- Create Database
CREATE DATABASE heritage_treasures;
USE heritage_treasures;

-- Create Table
CREATE TABLE heritage_sites (
    site_id INT PRIMARY KEY,
    site_name VARCHAR(255),
    country VARCHAR(100),
    category VARCHAR(100),
    annual_visitors INT,
    revenue_million DECIMAL(10,2),
    year INT
);

-- Sample Query
SELECT country, COUNT(*) AS total_sites
FROM heritage_sites
GROUP BY country
ORDER BY total_sites DESC;
